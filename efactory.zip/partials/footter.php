<footer>
    <div>© 2023 Efactory Coffee Colombian Coffee Efactory LLC</div>
    <div class="socials">
        <a href="www.facebook.com" target=_blank" class="item">
            <Image src="/imgs/facebook.svg" alt="facebook" width=20px height=20px />
        </a>
        <a href="www.instagram.com" target=_blank" class="item">
            <Image src="/imgs/instagram.svg" alt="instagram" width=20px height=20px />
        </a>
        <a href="www.twitter.com" target=_blank" class="item">
            <Image src="/imgs/twitter.svg" alt="twitter" width=20px height=20px />
        </a>
    </div>
</footer>
<div class="credits">Jsm Soluciones Valledupar - 312 679 84 61</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.2/dist/umd/popper.min.js" integrity="sha384-q9CRHqZndzlxGLOj+xrdLDJa9ittGte1NksRmgJKeCV9DrM7Kz868XYqsKWPpAmn" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<script src="/js/app.js"></script>
</body>

</html>